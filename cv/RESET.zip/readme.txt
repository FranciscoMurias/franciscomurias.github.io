A game made in Porto Graphics Game Jam 2015
by Francisco Múrias; Henrique Pinto; Paulo Pinho; Vitór Araujo

Use the mouse buttons to absorb and create cubes, and the wasd keys to move.
